import { motion } from 'framer-motion';
import { KarvaMark } from './Logo';
import { MagneticButton } from './MagneticButton';
import { container, item, EASE } from '../lib/anim';
import { Typewriter } from './Typewriter';

export function Hero() {
  return (
    <section id="top" className="relative flex min-h-screen items-center justify-center overflow-hidden px-6">
      {/* animated gradient blobs */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="grid-bg absolute inset-0 opacity-60 [mask-image:radial-gradient(ellipse_at_center,black,transparent_75%)]" />
        <div className="animate-float-gradient absolute left-1/4 top-1/4 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-violet-700/25 blur-[130px]" />
        <div className="animate-float-gradient-2 absolute right-1/4 top-1/3 h-[460px] w-[460px] translate-x-1/2 rounded-full bg-blue-700/20 blur-[140px]" />
        <div className="absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-black to-transparent" />
      </div>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="mx-auto flex max-w-4xl flex-col items-center text-center"
      >
        <motion.div
          variants={item}
          className="mb-8"
          initial={{ scale: 0.6, rotate: -12, opacity: 0 }}
          animate={{ scale: 1, rotate: 0, opacity: 1 }}
          transition={{ duration: 1, ease: EASE, delay: 0.1 }}
        >
          <div className="relative">
            <div className="absolute inset-0 -z-10 rounded-3xl bg-violet-500/25 blur-2xl" />
            <KarvaMark size={78} />
          </div>
        </motion.div>

        <motion.span
          variants={item}
          className="mb-6 inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs tracking-[0.2em] text-white/70"
        >
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_10px_2px_rgba(52,211,153,0.7)]" />
          KARVA DIGITAL SERVICES
        </motion.span>

        <motion.h1
          variants={item}
          className="font-display font-bold leading-[1.04] tracking-tight"
        >
          <span className="block text-6xl tracking-[0.15em] text-white sm:text-7xl md:text-8xl">KARVA</span>
          <span className="mt-6 block text-3xl sm:text-4xl md:text-5xl">Simple plans. Clear pricing.</span>
          <span className="mt-2 block min-h-[1.1em] text-3xl sm:text-4xl md:text-5xl">
            <Typewriter
              words={['Websites.', 'Social Media.', 'Design.', 'Video Editing.', 'Marketing.']}
              className="text-gradient"
            />
          </span>
        </motion.h1>

        <motion.p
          variants={item}
          className="mt-7 max-w-xl text-base leading-relaxed text-white/55 sm:text-lg"
        >
          A clean pricing guide for everything your business needs to build a consistent digital presence.
        </motion.p>

        <motion.div variants={item} className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <MagneticButton href="#monthly-plans" variant="primary">
            View Pricing
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
              <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </MagneticButton>
          <MagneticButton href="#websites" variant="ghost">
            Website Plans
          </MagneticButton>
        </motion.div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/30"
      >
        <span className="text-[10px] tracking-[0.3em]">SCROLL</span>
        <motion.span
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.6, repeat: Infinity }}
          className="block h-6 w-px bg-gradient-to-b from-white/50 to-transparent"
        />
      </motion.div>
    </section>
  );
}
