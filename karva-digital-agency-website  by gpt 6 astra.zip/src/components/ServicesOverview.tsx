import { motion } from 'framer-motion';
import { SectionHeading } from './Section';
import { EASE } from '../lib/anim';

const services = [
  {
    icon: '🌐',
    title: 'Website Development',
    desc: 'Fast, modern, conversion-focused websites — from starter sites to premium builds.',
    href: '#websites',
  },
  {
    icon: '📱',
    title: 'Social Media Management',
    desc: 'End-to-end handling — content, design, reels, posting & growth strategy.',
    href: '#social',
  },
  {
    icon: '📈',
    title: 'Digital Marketing',
    desc: 'Campaigns, local marketing, SEO & Google presence that actually convert.',
    href: '#marketing',
  },
  {
    icon: '🎨',
    title: 'Branding & Design',
    desc: 'Logos, brand identity, posters, creatives and clean UI/UX systems.',
    href: '#branding',
  },
  {
    icon: '💻',
    title: 'Custom Digital Solutions',
    desc: 'Web apps, dashboards, booking systems, business tools & automation.',
    href: '#custom',
  },
  {
    icon: '🔥',
    title: 'Complete Business Package',
    desc: 'Website + Social + Marketing + Branding — one custom quotation.',
    href: '#package',
  },
];

export function ServicesOverview() {
  return (
    <section id="services" className="relative mx-auto max-w-6xl px-6 py-28">
      <SectionHeading
        eyebrow="WHAT WE DO"
        title={<>Everything your brand needs, <span className="text-gradient">under one roof</span></>}
        subtitle="Six focused services designed to launch, run and scale your business online."
      />

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {services.map((s, i) => (
          <motion.a
            key={s.title}
            href={s.href}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6, ease: EASE, delay: (i % 3) * 0.08 }}
            whileHover={{ y: -6 }}
            className="group relative overflow-hidden rounded-2xl glass p-7 transition-colors hover:border-violet-400/30"
          >
            <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-violet-600/0 blur-2xl transition-all duration-500 group-hover:bg-violet-600/20" />
            <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-white/5 text-2xl transition-transform duration-500 group-hover:scale-110">
              {s.icon}
            </div>
            <h3 className="font-display text-lg font-semibold text-white">{s.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-white/55">{s.desc}</p>
            <span className="mt-5 inline-flex items-center gap-1 text-sm text-violet-300 opacity-0 transition-all duration-300 group-hover:translate-x-1 group-hover:opacity-100">
              Explore
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
                <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </span>
          </motion.a>
        ))}
      </div>
    </section>
  );
}
