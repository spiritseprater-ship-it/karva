import { AnimatePresence, motion } from 'framer-motion';
import { AnimatedNumber } from './AnimatedNumber';
import { SectionHeading } from './Section';
import { EASE } from '../lib/anim';

type FeatureGroup = {
  title: string;
  features: string[];
};

const plans: Array<{
  name: string;
  price: number;
  audience: string;
  includes?: string;
  accent: string;
  glow: string;
  featured?: boolean;
  groups: FeatureGroup[];
}> = [
  {
    name: 'Basic',
    price: 4999,
    audience: 'For small businesses starting online',
    accent: 'text-emerald-300',
    glow: 'from-emerald-500/20',
    groups: [
      {
        title: 'Social Media',
        features: [
          'Instagram & Facebook management',
          '8 posts per month',
          '4 reels per month',
          'Captions + hashtags',
          'Posting & scheduling',
          'Basic content planning',
        ],
      },
      {
        title: 'Design',
        features: ['8 social media creatives', '2 posters per month', 'Basic promotional designs'],
      },
      {
        title: 'Video Editing',
        features: ['4 short-form video/reel edits', 'Basic transitions, text & music'],
      },
      {
        title: 'Digital',
        features: ['Basic Google Business/Profile assistance', 'Basic digital consultation'],
      },
    ],
  },
  {
    name: 'Pro',
    price: 9999,
    audience: 'For businesses that want consistent digital growth',
    includes: 'Everything in Basic, plus',
    accent: 'text-blue-300',
    glow: 'from-blue-500/25',
    featured: true,
    groups: [
      {
        title: 'Social Media',
        features: [
          '12–16 posts per month',
          '8 reels per month',
          'Instagram + Facebook management',
          'Monthly content calendar',
          'Engagement monitoring',
          'Profile optimization',
        ],
      },
      {
        title: 'Design',
        features: [
          '12–16 custom creatives',
          '4 promotional posters',
          'Offer / festival creatives',
          'Menu, product & service creatives',
        ],
      },
      {
        title: 'Video Editing',
        features: [
          '8 reels / short videos',
          'Advanced transitions',
          'Text animations & branding',
          'Music / sound syncing',
        ],
      },
      {
        title: 'Digital Marketing',
        features: [
          'Basic campaign strategy',
          'Local marketing strategy',
          'SEO fundamentals',
          'Google Business optimization',
          'Monthly performance report',
        ],
      },
    ],
  },
  {
    name: 'Pro Plus',
    price: 17999,
    audience: 'Complete digital presence for growing businesses',
    includes: 'Everything in Pro, plus',
    accent: 'text-violet-300',
    glow: 'from-violet-500/25',
    groups: [
      {
        title: 'Social Media',
        features: [
          '20+ posts per month',
          '12 reels per month',
          'Instagram + Facebook + 1 platform',
          'Complete content strategy',
          'Audience & competitor research',
          'Monthly analytics',
        ],
      },
      {
        title: 'Premium Design',
        features: [
          '20+ custom creatives',
          'Promotional campaigns & posters',
          'Offer / festival creatives',
          'Product & service creatives',
          'Brand-consistent design system',
        ],
      },
      {
        title: 'Video',
        features: [
          '12–16 professional reel edits',
          'Advanced editing & motion graphics',
          'Text animation & color correction',
          'Sound design',
        ],
      },
      {
        title: 'Digital Marketing',
        features: [
          'Local SEO & Google optimization',
          'Campaign planning',
          'Social media marketing strategy',
          'Basic ad-management support',
          'Monthly analytics / report',
        ],
      },
      {
        title: 'Branding',
        features: [
          'Brand visual direction',
          'Social media identity',
          'Basic brand guidelines',
          'Consistent fonts, colors & design language',
        ],
      },
    ],
  },
];

function Check() {
  return (
    <span className="mt-1 flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-full bg-white/[0.07] text-white/55">
      <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5">
        <path d="M20 6 9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </span>
  );
}

export type PlanName = 'Basic' | 'Pro' | 'Pro Plus';

const planPrices: Record<PlanName, string> = {
  Basic: '₹4,999/month',
  Pro: '₹9,999/month',
  'Pro Plus': '₹17,999/month',
};

export function DigitalPlans({
  selectedPlan,
  onSelect,
}: {
  selectedPlan: PlanName | null;
  onSelect: (plan: PlanName) => void;
}) {
  return (
    <section id="monthly-plans" className="relative mx-auto max-w-7xl px-6 py-28">
      <SectionHeading
        eyebrow="MONTHLY DIGITAL SERVICES"
        title={<>Choose your <span className="text-gradient">growth plan</span></>}
        subtitle="Social media, design, video and digital support combined into three simple monthly plans."
      />

      <AnimatePresence>
        {selectedPlan && (
          <motion.div
            initial={{ opacity: 0, y: -12, height: 0 }}
            animate={{ opacity: 1, y: 0, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-7 overflow-hidden"
          >
            <div className="flex flex-col items-start justify-between gap-4 rounded-2xl border border-violet-400/25 bg-violet-500/[0.06] px-5 py-4 sm:flex-row sm:items-center">
              <div className="flex items-center gap-3">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-violet-400/15 text-violet-200">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                    <path d="M20 6 9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </span>
                <div>
                  <span className="block text-[10px] font-semibold tracking-[0.18em] text-white/35">SELECTED PLAN</span>
                  <span className="font-display text-base font-semibold text-white">{selectedPlan} · {planPrices[selectedPlan]}</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => window.print()}
                className="rounded-full border border-white/10 px-4 py-2 text-xs text-white/65 transition-colors hover:border-white/25 hover:text-white"
              >
                Save Pricing as PDF
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid items-start gap-6 lg:grid-cols-3">
        {plans.map((plan, index) => (
          <motion.article
            key={plan.name}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.72, ease: EASE, delay: index * 0.09 }}
            whileHover={{ y: -7 }}
            className={`relative overflow-hidden rounded-[1.75rem] border p-7 sm:p-8 ${
              selectedPlan === plan.name
                ? 'border-violet-300/60 bg-violet-500/[0.09] shadow-[0_24px_80px_-42px_rgba(139,92,246,1)]'
                : plan.featured
                ? 'border-blue-400/40 bg-blue-500/[0.07] shadow-[0_24px_80px_-42px_rgba(59,130,246,0.9)]'
                : 'border-white/10 bg-white/[0.025]'
            }`}
          >
            <div className={`pointer-events-none absolute inset-x-0 top-0 h-44 bg-gradient-to-b ${plan.glow} to-transparent opacity-45`} />
            <div className="relative">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-2.5">
                  <span className={`h-2.5 w-2.5 rounded-full bg-current ${plan.accent} shadow-[0_0_14px_currentColor]`} />
                  <h3 className="font-display text-sm font-bold uppercase tracking-[0.2em] text-white">{plan.name}</h3>
                </div>
                {plan.featured && (
                  <span className="rounded-full bg-blue-400/15 px-3 py-1 text-[10px] font-semibold tracking-[0.18em] text-blue-200">
                    RECOMMENDED
                  </span>
                )}
              </div>

              <div className="mt-6 flex items-end gap-1.5">
                <span className="font-display text-4xl font-bold tracking-tight text-white sm:text-5xl">
                  <AnimatedNumber value={plan.price} prefix="₹" />
                </span>
                <span className="pb-1 text-sm text-white/40">/month</span>
              </div>
              <p className="mt-3 min-h-10 text-sm leading-relaxed text-white/55">{plan.audience}</p>

              {plan.includes && (
                <p className={`mt-5 border-y border-white/[0.08] py-3 text-xs font-medium uppercase tracking-[0.16em] ${plan.accent}`}>
                  {plan.includes}
                </p>
              )}

              <div className={`${plan.includes ? 'mt-6' : 'mt-7'} space-y-6`}>
                {plan.groups.map((group) => (
                  <div key={group.title}>
                    <h4 className={`mb-3 text-xs font-semibold uppercase tracking-[0.18em] ${plan.accent}`}>
                      {group.title}
                    </h4>
                    <ul className="space-y-2.5">
                      {group.features.map((feature) => (
                        <li key={feature} className="flex items-start gap-2.5 text-[13px] leading-relaxed text-white/66">
                          <Check />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>

              <button
                type="button"
                onClick={() => onSelect(plan.name as PlanName)}
                className={`mt-7 w-full rounded-xl py-3 text-sm font-medium transition-all ${
                  selectedPlan === plan.name
                    ? 'bg-white text-black'
                    : 'border border-white/10 bg-white/[0.03] text-white/65 hover:border-white/25 hover:text-white'
                }`}
              >
                {selectedPlan === plan.name ? 'Selected' : `Select ${plan.name}`}
              </button>
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  );
}