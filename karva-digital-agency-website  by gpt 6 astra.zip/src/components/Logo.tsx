import { motion } from 'framer-motion';

export function KarvaMark({ size = 40 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="shrink-0"
    >
      <defs>
        <linearGradient id="karvaGrad" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
          <stop stopColor="#a78bfa" />
          <stop offset="1" stopColor="#3b82f6" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="60" height="60" rx="16" stroke="url(#karvaGrad)" strokeWidth="2.5" />
      {/* Stylised K */}
      <path
        d="M22 16V48"
        stroke="url(#karvaGrad)"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <path
        d="M42 16L24 31L44 48"
        stroke="url(#karvaGrad)"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function Logo({ size = 40, showText = true }: { size?: number; showText?: boolean }) {
  return (
    <motion.a
      href="#top"
      className="flex items-center gap-3 select-none"
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
    >
      <KarvaMark size={size} />
      {showText && (
        <span className="font-display text-xl font-bold tracking-[0.25em] text-white">
          KARVA
        </span>
      )}
    </motion.a>
  );
}
