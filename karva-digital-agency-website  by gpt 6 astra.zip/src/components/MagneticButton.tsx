import { useRef, useState, type ReactNode } from 'react';
import { motion } from 'framer-motion';

interface Props {
  children: ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: 'primary' | 'ghost';
  className?: string;
  strength?: number;
}

export function MagneticButton({
  children,
  href = '#',
  onClick,
  variant = 'primary',
  className = '',
  strength = 0.35,
}: Props) {
  const ref = useRef<HTMLAnchorElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });

  const handleMove = (e: React.MouseEvent) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const relX = e.clientX - (rect.left + rect.width / 2);
    const relY = e.clientY - (rect.top + rect.height / 2);
    setPos({ x: relX * strength, y: relY * strength });
  };

  const reset = () => setPos({ x: 0, y: 0 });

  const base =
    'relative inline-flex items-center justify-center gap-2 rounded-full px-7 py-3.5 text-sm font-medium tracking-wide overflow-hidden group';
  const styles =
    variant === 'primary'
      ? 'text-white bg-gradient-to-r from-violet-600 to-blue-600 shadow-[0_8px_30px_-8px_rgba(99,102,241,0.7)]'
      : 'text-white/90 glass hover:border-white/25';

  return (
    <motion.a
      ref={ref}
      href={href}
      onClick={onClick}
      onMouseMove={handleMove}
      onMouseLeave={reset}
      animate={{ x: pos.x, y: pos.y }}
      transition={{ type: 'spring', stiffness: 200, damping: 15, mass: 0.3 }}
      className={`${base} ${styles} ${className}`}
    >
      <span className="relative z-10 flex items-center gap-2">{children}</span>
      {variant === 'primary' && (
        <span className="absolute inset-0 z-0 translate-y-full bg-gradient-to-r from-blue-500 to-violet-500 transition-transform duration-500 group-hover:translate-y-0" />
      )}
    </motion.a>
  );
}
