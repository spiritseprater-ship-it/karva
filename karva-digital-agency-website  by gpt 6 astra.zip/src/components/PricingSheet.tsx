const monthly = [
  ['Basic', '₹4,999/month', '8 posts, 4 reels, social management, 8 creatives, 2 posters, 4 video edits, Google profile assistance'],
  ['Pro', '₹9,999/month', '12–16 posts, 8 reels, custom creatives, advanced editing, campaign strategy, SEO fundamentals, monthly report'],
  ['Pro Plus', '₹17,999/month', '20+ posts, 12 reels, 3 platforms, research, premium design, motion graphics, local SEO, branding direction'],
];

const websites = [
  ['Starter', '₹7,000'],
  ['Professional', '₹15,000'],
  ['Premium', '₹30,000–₹35,000'],
];

const individual = [
  ['Poster / Social Creative', '₹250–₹500'], ['Premium Poster', '₹500–₹800'],
  ['Reel Editing', '₹500–₹1,000'], ['Advanced Reel', '₹1,000–₹2,000'],
  ['Video Editing', '₹1,000+'], ['Logo Design', '₹1,500–₹3,000'],
  ['Basic Branding', '₹3,000–₹7,000'], ['Social Media Setup', '₹1,500–₹3,000'],
  ['Social Media Management', '₹4,999+/month'], ['SEO', '₹3,000+/month'],
  ['Digital Marketing', '₹5,000+/month'],
];

export function PricingSheet() {
  return (
    <div className="print-sheet hidden">
      <header className="print-header">
        <div>
          <div className="print-brand">KARVA</div>
          <div className="print-subtitle">Digital Services Pricing</div>
        </div>
        <div className="print-year">2026</div>
      </header>

      <h1>Monthly Digital Plans</h1>
      <div className="print-plans">
        {monthly.map(([name, price, summary]) => (
          <div className="print-plan" key={name}>
            <h2>{name}</h2>
            <strong>{price}</strong>
            <p>{summary}</p>
          </div>
        ))}
      </div>

      <div className="print-two-col">
        <section>
          <h1>Website Development</h1>
          {websites.map(([name, price]) => <div className="print-row" key={name}><span>{name}</span><b>{price}</b></div>)}
          <small>Domain and hosting charged separately.</small>
        </section>
        <section>
          <h1>Individual Services</h1>
          {individual.map(([name, price]) => <div className="print-row" key={name}><span>{name}</span><b>{price}</b></div>)}
        </section>
      </div>

      <footer className="print-footer">Final pricing may vary based on scope, complexity and delivery requirements.</footer>
    </div>
  );
}