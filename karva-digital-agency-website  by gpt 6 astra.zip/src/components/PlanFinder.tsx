import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { EASE } from '../lib/anim';

type PlanName = 'Basic' | 'Pro' | 'Pro Plus';

const questions = [
  {
    title: 'What is your main goal?',
    options: [
      { label: 'Start my business online', hint: 'A reliable, professional beginning', score: 0 },
      { label: 'Grow consistently every month', hint: 'More content, strategy and reporting', score: 1 },
      { label: 'Build a complete digital presence', hint: 'Content, marketing and branding together', score: 2 },
    ],
  },
  {
    title: 'How much monthly content do you need?',
    options: [
      { label: '8 posts + 4 reels', hint: 'Essential monthly consistency', score: 0 },
      { label: '12–16 posts + 8 reels', hint: 'A strong, active presence', score: 1 },
      { label: '20+ posts + 12 reels', hint: 'High-volume brand communication', score: 2 },
    ],
  },
  {
    title: 'What level of support fits you?',
    options: [
      { label: 'Social media + basic design', hint: 'The core essentials', score: 0 },
      { label: 'Strategy + SEO + reporting', hint: 'Performance-focused support', score: 1 },
      { label: 'Research + marketing + branding', hint: 'Complete direction and execution', score: 2 },
    ],
  },
] as const;

const resultData: Record<PlanName, { price: string; copy: string; color: string }> = {
  Basic: {
    price: '₹4,999/month',
    copy: 'The essentials for building a consistent and professional online presence.',
    color: 'text-emerald-300',
  },
  Pro: {
    price: '₹9,999/month',
    copy: 'The best balance of content, design, video and growth support.',
    color: 'text-blue-300',
  },
  'Pro Plus': {
    price: '₹17,999/month',
    copy: 'A complete, high-volume digital presence with strategy and brand direction.',
    color: 'text-violet-300',
  },
};

export function PlanFinder({ onRecommend }: { onRecommend: (plan: PlanName) => void }) {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const complete = answers.length === questions.length;

  const recommendation = useMemo<PlanName>(() => {
    const score = answers.reduce((sum, answer) => sum + answer, 0);
    if (score <= 1) return 'Basic';
    if (score <= 4) return 'Pro';
    return 'Pro Plus';
  }, [answers]);

  const choose = (score: number) => {
    const next = [...answers.slice(0, step), score];
    setAnswers(next);
    if (step < questions.length - 1) setStep((current) => current + 1);
  };

  const reset = () => {
    setAnswers([]);
    setStep(0);
  };

  const viewPlan = () => {
    onRecommend(recommendation);
    document.querySelector('#monthly-plans')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="mx-auto max-w-4xl px-6 py-24">
      <motion.div
        initial={{ opacity: 0, y: 35 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }}
        transition={{ duration: 0.7, ease: EASE }}
        className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.025] p-6 sm:p-10"
      >
        <div className="pointer-events-none absolute right-0 top-0 h-64 w-64 rounded-full bg-violet-600/10 blur-[90px]" />
        <div className="relative">
          <div className="flex flex-col justify-between gap-4 border-b border-white/10 pb-6 sm:flex-row sm:items-end">
            <div>
              <span className="text-[10px] font-semibold tracking-[0.22em] text-violet-300">PLAN FINDER</span>
              <h2 className="mt-2 font-display text-2xl font-bold sm:text-3xl">Find your plan in 30 seconds</h2>
            </div>
            {!complete && (
              <span className="text-xs text-white/35">Question {step + 1} of {questions.length}</span>
            )}
          </div>

          <div className="mt-7 h-1 overflow-hidden rounded-full bg-white/[0.06]">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-violet-500 to-blue-500"
              animate={{ width: complete ? '100%' : `${((step + 1) / questions.length) * 100}%` }}
              transition={{ duration: 0.5, ease: EASE }}
            />
          </div>

          <AnimatePresence mode="wait">
            {!complete ? (
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.35, ease: EASE }}
                className="mt-8"
              >
                <h3 className="font-display text-lg font-semibold text-white">{questions[step].title}</h3>
                <div className="mt-5 grid gap-3 sm:grid-cols-3">
                  {questions[step].options.map((option) => (
                    <button
                      key={option.label}
                      type="button"
                      onClick={() => choose(option.score)}
                      className="group min-h-28 rounded-2xl border border-white/10 bg-white/[0.025] p-4 text-left transition-all hover:-translate-y-1 hover:border-violet-400/40 hover:bg-violet-500/[0.06]"
                    >
                      <span className="block text-sm font-medium text-white/85 group-hover:text-white">{option.label}</span>
                      <span className="mt-2 block text-xs leading-relaxed text-white/38">{option.hint}</span>
                    </button>
                  ))}
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="result"
                initial={{ opacity: 0, scale: 0.97 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.45, ease: EASE }}
                className="mt-8 flex flex-col justify-between gap-7 sm:flex-row sm:items-end"
              >
                <div>
                  <span className="text-xs tracking-[0.18em] text-white/40">YOUR BEST MATCH</span>
                  <h3 className={`mt-2 font-display text-4xl font-bold ${resultData[recommendation].color}`}>
                    {recommendation}
                  </h3>
                  <p className="mt-1 font-display text-xl font-semibold text-white">{resultData[recommendation].price}</p>
                  <p className="mt-3 max-w-md text-sm leading-relaxed text-white/50">{resultData[recommendation].copy}</p>
                </div>
                <div className="flex flex-wrap gap-3">
                  <button type="button" onClick={reset} className="rounded-full border border-white/10 px-5 py-2.5 text-sm text-white/60 hover:text-white">
                    Start Again
                  </button>
                  <button type="button" onClick={viewPlan} className="rounded-full bg-white px-5 py-2.5 text-sm font-medium text-black transition-transform hover:scale-105">
                    View {recommendation}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </section>
  );
}