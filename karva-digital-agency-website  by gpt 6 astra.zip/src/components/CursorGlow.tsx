import { useEffect } from 'react';
import { motion, useMotionValue, useSpring } from 'framer-motion';

export function CursorGlow() {
  const x = useMotionValue(-500);
  const y = useMotionValue(-500);
  const sx = useSpring(x, { stiffness: 120, damping: 20, mass: 0.4 });
  const sy = useSpring(y, { stiffness: 120, damping: 20, mass: 0.4 });

  useEffect(() => {
    const move = (e: MouseEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
    };
    window.addEventListener('mousemove', move);
    return () => window.removeEventListener('mousemove', move);
  }, [x, y]);

  return (
    <motion.div
      aria-hidden
      className="pointer-events-none fixed z-[5] hidden md:block"
      style={{
        left: sx,
        top: sy,
        translateX: '-50%',
        translateY: '-50%',
      }}
    >
      <div className="h-[500px] w-[500px] rounded-full bg-[radial-gradient(circle,rgba(124,58,237,0.14),rgba(37,99,235,0.06)_40%,transparent_70%)]" />
    </motion.div>
  );
}
