import { motion } from 'framer-motion';
import { SectionHeading } from './Section';
import { MagneticButton } from './MagneticButton';
import { EASE } from '../lib/anim';

const capabilities = [
  { t: 'Account Handling', d: 'Full management of Instagram & other platforms.' },
  { t: 'Content Planning', d: 'Monthly calendars mapped to your goals.' },
  { t: 'Post Design', d: 'On-brand, scroll-stopping creatives.' },
  { t: 'Reels', d: 'Trend-aware short-form video that performs.' },
  { t: 'Captions', d: 'Copy that speaks to your audience.' },
  { t: 'Posting', d: 'Consistent scheduling — we handle it all.' },
  { t: 'Growth Strategy', d: 'Data-led tactics to grow real reach.' },
  { t: 'Analytics', d: 'Clear monthly reports on what works.' },
];

export function Social() {
  return (
    <section id="social" className="relative mx-auto max-w-6xl px-6 py-28">
      <SectionHeading
        eyebrow="📱 SOCIAL MEDIA MANAGEMENT"
        title={<>Your socials, <span className="text-gradient">fully handled</span></>}
        subtitle="Instagram and beyond — we plan, design, post and grow, so you can focus on your business."
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {capabilities.map((c, i) => (
          <motion.div
            key={c.t}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.55, ease: EASE, delay: (i % 4) * 0.07 }}
            className="group rounded-2xl glass p-6 transition-colors hover:border-blue-400/30"
          >
            <div className="mb-3 h-1 w-8 rounded-full bg-gradient-to-r from-violet-400 to-blue-400 transition-all duration-300 group-hover:w-14" />
            <h3 className="font-display text-base font-semibold text-white">{c.t}</h3>
            <p className="mt-1.5 text-sm text-white/50">{c.d}</p>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, ease: EASE }}
        className="mt-10 flex flex-col items-center justify-between gap-6 rounded-3xl bg-gradient-to-r from-violet-600/15 to-blue-600/10 p-8 text-center sm:flex-row sm:text-left"
      >
        <div>
          <span className="inline-block rounded-full bg-white/10 px-3 py-1 text-xs tracking-widest text-white/70">
            PRICING
          </span>
          <h3 className="mt-3 font-display text-2xl font-bold text-white">Custom Plan — Let's Discuss</h3>
          <p className="mt-1 text-sm text-white/55">
            Every brand is different. We'll build a plan (and price) around your exact needs.
          </p>
        </div>
        <MagneticButton href="#contact" variant="primary" strength={0.25}>
          Let's Discuss
        </MagneticButton>
      </motion.div>
    </section>
  );
}
