import { useEffect, useState } from 'react';

export function Typewriter({
  words,
  className = '',
}: {
  words: string[];
  className?: string;
}) {
  const [wordIndex, setWordIndex] = useState(0);
  const [length, setLength] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const word = words[wordIndex];
    const complete = length === word.length;
    const empty = length === 0;
    const delay = complete && !deleting ? 1250 : deleting ? 38 : 68;

    const timer = window.setTimeout(() => {
      if (complete && !deleting) {
        setDeleting(true);
        return;
      }
      if (empty && deleting) {
        setDeleting(false);
        setWordIndex((current) => (current + 1) % words.length);
        return;
      }
      setLength((current) => current + (deleting ? -1 : 1));
    }, delay);

    return () => window.clearTimeout(timer);
  }, [deleting, length, wordIndex, words]);

  return (
    <span className={className} aria-label={words[wordIndex]}>
      {words[wordIndex].slice(0, length)}
      <span className="ml-1 inline-block h-[0.9em] w-[2px] animate-pulse bg-violet-300 align-[-0.06em]" />
    </span>
  );
}