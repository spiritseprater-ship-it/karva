import { motion } from 'framer-motion';
import { SectionHeading } from './Section';
import { EASE } from '../lib/anim';

function PillGrid({ items, accent }: { items: string[]; accent: string }) {
  return (
    <div className="flex flex-wrap justify-center gap-3">
      {items.map((it, i) => (
        <motion.span
          key={it}
          initial={{ opacity: 0, scale: 0.9, y: 12 }}
          whileInView={{ opacity: 1, scale: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
          transition={{ duration: 0.45, ease: EASE, delay: i * 0.05 }}
          whileHover={{ y: -4 }}
          className={`rounded-full glass px-5 py-2.5 text-sm text-white/80 transition-colors ${accent}`}
        >
          {it}
        </motion.span>
      ))}
    </div>
  );
}

export function Marketing() {
  return (
    <section id="marketing" className="relative mx-auto max-w-4xl px-6 py-28">
      <SectionHeading
        eyebrow="📈 DIGITAL MARKETING"
        title={<>Get <span className="text-gradient">found & chosen</span></>}
        subtitle="From social ads to SEO, we drive visibility that turns into customers."
      />
      <PillGrid
        accent="hover:border-emerald-400/40"
        items={[
          'Social Media Marketing',
          'Campaign Management',
          'Local Marketing',
          'SEO',
          'Google Presence',
          'Lead Generation',
          'Performance Ads',
          'Reporting & Optimisation',
        ]}
      />
    </section>
  );
}

export function Branding() {
  return (
    <section id="branding" className="relative mx-auto max-w-4xl px-6 py-28">
      <SectionHeading
        eyebrow="🎨 BRANDING & DESIGN"
        title={<>A brand people <span className="text-gradient">remember</span></>}
        subtitle="Identity systems and creatives that make you look every bit as good as you are."
      />
      <PillGrid
        accent="hover:border-pink-400/40"
        items={['Logo', 'Brand Identity', 'Posters', 'Social Creatives', 'UI/UX', 'Brand Guidelines']}
      />
    </section>
  );
}

export function CustomSolutions() {
  const items = [
    { icon: '🧩', t: 'Web Apps', d: 'Bespoke applications built for your workflow.' },
    { icon: '📊', t: 'Dashboards', d: 'Live data & insights in one clean view.' },
    { icon: '📅', t: 'Booking Systems', d: 'Let customers book you 24/7.' },
    { icon: '🛠️', t: 'Business Tools', d: 'Internal tools tailored to your team.' },
    { icon: '⚡', t: 'Automation', d: 'Cut repetitive work and save hours.' },
  ];
  return (
    <section id="custom" className="relative mx-auto max-w-6xl px-6 py-28">
      <SectionHeading
        eyebrow="💻 CUSTOM DIGITAL SOLUTIONS"
        title={<>Built <span className="text-gradient">exactly</span> for your business</>}
        subtitle="When off-the-shelf isn't enough, we engineer the tools you actually need."
      />
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
        {items.map((it, i) => (
          <motion.div
            key={it.t}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.55, ease: EASE, delay: i * 0.07 }}
            whileHover={{ y: -6 }}
            className="rounded-2xl glass p-6 text-center transition-colors hover:border-indigo-400/30"
          >
            <div className="mb-3 text-3xl">{it.icon}</div>
            <h3 className="font-display text-sm font-semibold text-white">{it.t}</h3>
            <p className="mt-1.5 text-xs text-white/50">{it.d}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
