import { motion } from 'framer-motion';
import { SectionHeading } from './Section';
import { EASE } from '../lib/anim';

const services = [
  ['Poster / Social Creative', '₹250–₹500'],
  ['Premium Poster', '₹500–₹800'],
  ['Reel Editing', '₹500–₹1,000'],
  ['Advanced Reel', '₹1,000–₹2,000'],
  ['Video Editing', '₹1,000+'],
  ['Logo Design', '₹1,500–₹3,000'],
  ['Basic Branding', '₹3,000–₹7,000'],
  ['Social Media Setup', '₹1,500–₹3,000'],
  ['Social Media Management', '₹4,999+/month'],
  ['SEO', '₹3,000+/month'],
  ['Digital Marketing', '₹5,000+/month'],
];

export function IndividualServices() {
  return (
    <section id="individual-services" className="relative mx-auto max-w-4xl px-6 py-28">
      <SectionHeading
        eyebrow="INDIVIDUAL SERVICES"
        title={<>Only need <span className="text-gradient">one thing?</span></>}
        subtitle="Choose individual services without committing to a full monthly package."
      />

      <motion.div
        initial={{ opacity: 0, y: 35 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-50px' }}
        transition={{ duration: 0.7, ease: EASE }}
        className="overflow-hidden rounded-[1.75rem] border border-white/10 bg-white/[0.025]"
      >
        <div className="grid grid-cols-[1fr_auto] gap-4 border-b border-white/10 px-6 py-4 text-[10px] font-semibold uppercase tracking-[0.2em] text-white/35 sm:px-8">
          <span>Service</span>
          <span>Starting Price</span>
        </div>
        <div>
          {services.map(([service, price], index) => (
            <motion.div
              key={service}
              initial={{ opacity: 0, x: -16 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.45, ease: EASE, delay: index * 0.035 }}
              className="group grid grid-cols-[1fr_auto] items-center gap-4 border-b border-white/[0.07] px-6 py-4 last:border-0 hover:bg-white/[0.035] sm:px-8"
            >
              <span className="text-sm text-white/70 transition-colors group-hover:text-white">{service}</span>
              <span className="font-display text-sm font-semibold text-violet-200 sm:text-base">{price}</span>
            </motion.div>
          ))}
        </div>
      </motion.div>

      <p className="mt-5 text-center text-xs leading-relaxed text-white/30">
        Final pricing may vary based on scope, complexity and delivery requirements.
      </p>
    </section>
  );
}