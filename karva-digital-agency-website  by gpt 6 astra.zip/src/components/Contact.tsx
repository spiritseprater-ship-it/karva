import { useState } from 'react';
import { motion } from 'framer-motion';
import { KarvaMark } from './Logo';
import { EASE } from '../lib/anim';

export function Contact() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', service: 'Website Development', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  const services = [
    'Website Development',
    'Social Media Management',
    'Digital Marketing',
    'Branding & Design',
    'Custom Digital Solutions',
    'Complete Business Package',
  ];

  return (
    <section id="contact" className="relative mx-auto max-w-5xl px-6 py-28">
      <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease: EASE }}
        >
          <span className="inline-block rounded-full glass px-4 py-1.5 text-xs tracking-[0.25em] text-violet-300/90">
            LET'S BUILD
          </span>
          <h2 className="mt-5 font-display text-4xl font-bold leading-tight sm:text-5xl">
            Tell us about <span className="text-gradient">your business</span>
          </h2>
          <p className="mt-5 max-w-md text-white/55">
            Share a few details and we'll get back with ideas and a plan tailored to you. No pressure, no jargon.
          </p>

          <div className="mt-10 space-y-4">
            <a href="mailto:hello@karva.studio" className="flex items-center gap-3 text-white/70 transition-colors hover:text-white">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/5">✉️</span>
              hello@karva.studio
            </a>
            <a href="https://wa.me/" className="flex items-center gap-3 text-white/70 transition-colors hover:text-white">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/5">💬</span>
              Chat on WhatsApp
            </a>
            <div className="flex items-center gap-3 text-white/70">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/5">📷</span>
              @karva.digital
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease: EASE, delay: 0.1 }}
          className="rounded-3xl glass p-7 sm:p-9"
        >
          {sent ? (
            <div className="flex h-full flex-col items-center justify-center py-12 text-center">
              <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/15 text-3xl">
                ✅
              </div>
              <h3 className="font-display text-2xl font-semibold">Thanks, {form.name || 'there'}!</h3>
              <p className="mt-2 text-white/55">We've received your message and will reply shortly.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="mb-1.5 block text-xs tracking-wide text-white/50">Name</label>
                <input
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition-colors focus:border-violet-400/50"
                  placeholder="Your name"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs tracking-wide text-white/50">Email</label>
                <input
                  required
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition-colors focus:border-violet-400/50"
                  placeholder="you@email.com"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-xs tracking-wide text-white/50">Service</label>
                <select
                  value={form.service}
                  onChange={(e) => setForm({ ...form, service: e.target.value })}
                  className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition-colors focus:border-violet-400/50"
                >
                  {services.map((s) => (
                    <option key={s} value={s} className="bg-zinc-900">
                      {s}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1.5 block text-xs tracking-wide text-white/50">Message</label>
                <textarea
                  rows={4}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="w-full resize-none rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white outline-none transition-colors focus:border-violet-400/50"
                  placeholder="Tell us a bit about your project..."
                />
              </div>
              <button
                type="submit"
                className="group relative w-full overflow-hidden rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 py-3.5 text-sm font-medium text-white transition-transform hover:scale-[1.02]"
              >
                Send Message
              </button>
            </form>
          )}
        </motion.div>
      </div>

      <footer className="mt-28 border-t border-white/10 pt-10">
        <div className="flex flex-col items-center justify-between gap-6 sm:flex-row">
          <div className="flex items-center gap-3">
            <KarvaMark size={30} />
            <span className="font-display tracking-[0.25em] text-white">KARVA</span>
          </div>
          <p className="text-sm text-white/40">Digital Solutions for Businesses</p>
          <p className="text-sm text-white/30">© {new Date().getFullYear()} KARVA. All rights reserved.</p>
        </div>
      </footer>
    </section>
  );
}
