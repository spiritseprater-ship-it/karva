import { motion } from 'framer-motion';
import { SectionHeading } from './Section';
import { AnimatedNumber } from './AnimatedNumber';
import { EASE } from '../lib/anim';

const tiers = [
  {
    name: 'Starter',
    price: 7000,
    priceLabel: null as string | null,
    tag: 'For getting online fast',
    features: [
      'Up to 4 pages',
      'Mobile responsive design',
      'Contact form & WhatsApp',
      'Basic on-page SEO',
      'Social media links',
      '1 round of revisions',
    ],
    highlight: false,
  },
  {
    name: 'Professional',
    price: 15000,
    priceLabel: null,
    tag: 'Most popular for businesses',
    features: [
      'Up to 8 pages',
      'Premium custom design',
      'Blog / gallery setup',
      'Advanced SEO structure',
      'Google Maps + Analytics',
      'Speed optimisation',
      '2 rounds of revisions',
    ],
    highlight: true,
  },
  {
    name: 'Premium',
    price: 30000,
    priceLabel: '₹30,000 – ₹35,000',
    tag: 'Full-scale digital presence',
    features: [
      'Unlimited core pages',
      'Bespoke animations & UI',
      'CMS / dashboard integration',
      'E-commerce ready',
      'Full SEO + performance',
      'Priority support',
      'Unlimited revisions (scope)',
    ],
    highlight: false,
  },
];

export function Websites() {
  return (
    <section id="websites" className="relative mx-auto max-w-6xl px-6 py-28">
      <SectionHeading
        eyebrow="WEBSITE DEVELOPMENT"
        title={<>Three clear <span className="text-gradient">website plans</span></>}
        subtitle="One-time website packages for businesses at every stage."
      />

      <div className="grid gap-6 lg:grid-cols-3">
        {tiers.map((t, i) => (
          <motion.div
            key={t.name}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.7, ease: EASE, delay: i * 0.1 }}
            whileHover={{ y: -8 }}
            className={`group relative flex flex-col overflow-hidden rounded-3xl p-8 transition-all duration-300 ${
              t.highlight
                ? 'bg-gradient-to-b from-violet-600/20 to-blue-600/5 border border-violet-400/40 shadow-[0_20px_60px_-25px_rgba(124,58,237,0.7)]'
                : 'glass hover:border-white/20'
            }`}
          >
            {t.highlight && (
              <span className="absolute right-6 top-6 rounded-full bg-gradient-to-r from-violet-500 to-blue-500 px-3 py-1 text-[10px] font-semibold tracking-widest text-white">
                POPULAR
              </span>
            )}
            <h3 className="font-display text-xl font-semibold text-white">{t.name}</h3>
            <p className="mt-1 text-sm text-white/50">{t.tag}</p>

            <div className="mt-6 flex items-end gap-1">
              <span className="font-display text-4xl font-bold text-white">
                {t.priceLabel ? (
                  '₹'
                ) : (
                  <AnimatedNumber value={t.price} prefix="₹" />
                )}
              </span>
              {t.priceLabel && (
                <span className="font-display text-2xl font-bold text-white/90">
                  {t.priceLabel.replace('₹', '')}
                </span>
              )}
            </div>
            <p className="mt-1 text-xs text-white/40">Domain & hosting charged separately</p>

            <ul className="mt-7 flex-1 space-y-3">
              {t.features.map((f) => (
                <li key={f} className="flex items-start gap-3 text-sm text-white/70">
                  <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-violet-500/20 text-violet-300">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5">
                      <path d="M20 6L9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </span>
                  {f}
                </li>
              ))}
            </ul>

          </motion.div>
        ))}
      </div>

      <p className="mt-8 text-center text-xs text-white/35">
        * Domain & hosting are billed separately based on your requirements.
      </p>
    </section>
  );
}
