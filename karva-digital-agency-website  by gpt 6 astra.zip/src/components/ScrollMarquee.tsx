import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

const words = ['WEBSITES', 'SOCIAL MEDIA', 'MARKETING', 'BRANDING', 'AUTOMATION', 'GROWTH'];

export function ScrollMarquee() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  });
  const x1 = useTransform(scrollYProgress, [0, 1], ['5%', '-25%']);
  const x2 = useTransform(scrollYProgress, [0, 1], ['-25%', '5%']);

  return (
    <div ref={ref} className="relative overflow-hidden py-16 select-none">
      <motion.div style={{ x: x1 }} className="flex whitespace-nowrap">
        {[...words, ...words].map((w, i) => (
          <span
            key={`a-${i}`}
            className="font-display text-6xl font-extrabold tracking-tight text-white/[0.05] sm:text-8xl"
          >
            {w} <span className="text-violet-500/20">•</span>{' '}
          </span>
        ))}
      </motion.div>
      <motion.div style={{ x: x2 }} className="mt-2 flex whitespace-nowrap">
        {[...words.slice().reverse(), ...words.slice().reverse()].map((w, i) => (
          <span
            key={`b-${i}`}
            className="font-display text-6xl font-extrabold tracking-tight text-white/[0.04] sm:text-8xl"
          >
            {w} <span className="text-blue-500/20">•</span>{' '}
          </span>
        ))}
      </motion.div>
    </div>
  );
}
