import { motion } from 'framer-motion';
import { MagneticButton } from './MagneticButton';
import { EASE } from '../lib/anim';

export function CompletePackage() {
  const parts = ['Website', 'Social Media', 'Marketing', 'Branding'];
  return (
    <section id="package" className="relative mx-auto max-w-5xl px-6 py-28">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }}
        transition={{ duration: 0.8, ease: EASE }}
        className="relative overflow-hidden rounded-[2rem] border border-violet-400/30 bg-gradient-to-br from-violet-700/25 via-black to-blue-700/20 p-10 text-center sm:p-16"
      >
        <div className="animate-float-gradient absolute -left-20 -top-20 h-72 w-72 rounded-full bg-violet-600/30 blur-[100px]" />
        <div className="animate-float-gradient-2 absolute -bottom-20 -right-16 h-72 w-72 rounded-full bg-blue-600/25 blur-[110px]" />

        <div className="relative">
          <span className="inline-block rounded-full glass px-4 py-1.5 text-xs tracking-[0.25em] text-violet-200">
            🔥 COMPLETE BUSINESS PACKAGE
          </span>
          <h2 className="mx-auto mt-6 max-w-2xl font-display text-3xl font-bold leading-tight sm:text-5xl">
            The whole digital presence, <span className="text-gradient">done for you</span>
          </h2>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            {parts.map((p, i) => (
              <div key={p} className="flex items-center gap-3">
                <span className="rounded-full bg-white/8 px-4 py-2 text-sm text-white/85">{p}</span>
                {i < parts.length - 1 && <span className="text-violet-300">+</span>}
              </div>
            ))}
          </div>

          <p className="mx-auto mt-8 max-w-lg text-white/60">
            One team, one point of contact, one custom quotation tailored to your goals and budget.
          </p>

          <div className="mt-10 flex justify-center">
            <MagneticButton href="#contact" variant="primary">
              Get a Custom Quotation
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </MagneticButton>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
