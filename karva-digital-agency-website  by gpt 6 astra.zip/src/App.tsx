import { useState } from 'react';
import { CursorGlow } from './components/CursorGlow';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { DigitalPlans } from './components/DigitalPlans';
import { Websites } from './components/Websites';
import { IndividualServices } from './components/IndividualServices';
import { Logo } from './components/Logo';
import { PlanFinder } from './components/PlanFinder';
import { PricingSheet } from './components/PricingSheet';
import type { PlanName } from './components/DigitalPlans';

export default function App() {
  const [selectedPlan, setSelectedPlan] = useState<PlanName | null>(null);

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-black text-white">
      <div className="screen-only">
        <CursorGlow />
        <Navbar />
        <main className="relative z-10">
          <Hero />
          <PlanFinder onRecommend={setSelectedPlan} />
          <DigitalPlans selectedPlan={selectedPlan} onSelect={setSelectedPlan} />
          <Websites />
          <IndividualServices />
        </main>
        <footer className="relative z-10 mx-auto flex max-w-6xl flex-col items-center justify-between gap-5 border-t border-white/10 px-6 py-10 sm:flex-row">
          <Logo size={30} />
          <p className="text-xs tracking-[0.16em] text-white/35">DIGITAL SERVICES PRICING</p>
          <p className="text-xs text-white/25">Prices may vary by project scope.</p>
        </footer>
      </div>
      <PricingSheet />
    </div>
  );
}
